﻿using FoodApp.Models.ViewModels;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace FoodApp.Data
{
    public class RestaurantService
    {
        string connectionString;

        public RestaurantService(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnectionString");
        }

        public List<RestaurantVM> GetList(int userId)
        {
            List<RestaurantVM> restaurants = new List<RestaurantVM>();
            SqlConnection connection = new SqlConnection(connectionString);
            string sql = $"select * from Restaurants where UserId = '{userId}'";
            using (SqlCommand cmd = new SqlCommand(sql, connection))
            {
                connection.Open();
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        RestaurantVM restaurant = new RestaurantVM();
                        restaurant.Id = (int)rdr["Id"];
                        restaurant.Name = (string)rdr["Name"];
                        restaurant.Location = (string)rdr["Location"];
                        restaurants.Add(restaurant);
                    }
                    rdr.Close();
                }
            }
            connection.Close();

            return restaurants;
        }

        //public Restaurant Get(int id)
        //{
        //    Restaurant restaurant = new Restaurant();
        //    SqlConnection connection = new SqlConnection(connectionString);
        //    string sql = $"select top 1 * from Restaurants where Id = '{id}'";
        //    using (SqlCommand cmd = new SqlCommand(sql, connection))
        //    {
        //        connection.Open();
        //        using (SqlDataReader rdr = cmd.ExecuteReader())
        //        {
        //            while (rdr.Read())
        //            {
        //                restaurant.Id = (int)rdr["Id"];
        //                restaurant.Name = (string)rdr["Name"];
        //                restaurant.Location = (string)rdr["Location"];
        //            }
        //            rdr.Close();
        //        }
        //    }
        //    connection.Close();

        //    return restaurant;
        //}

        //public void Update(RestaurantVM restaurantVM)
        //{
        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        string sql = $"update Restaurants set Name = '{restaurantVM.Name}', Location = '{restaurantVM.Location}' where Id = {restaurantVM.Id}";

        //        using (SqlCommand command = new SqlCommand(sql, connection))
        //        {
        //            command.CommandType = CommandType.Text;
        //            connection.Open();
        //            command.ExecuteNonQuery();
        //            connection.Close();
        //        }
        //    }
        //}

        public void Create(RestaurantVM restaurantVM, int userId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = $"insert into Restaurants (Name, Location, UserId) values ('{restaurantVM.Name}', '{restaurantVM.Location}', '{userId}')";

                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.CommandType = CommandType.Text;
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
        }
    }
}
