﻿using FoodApp.Models.ViewModels;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Data;
using FoodApp.Models.Tables;

namespace FoodApp.Data
{
    public class FoodItemService
    {
        string connectionString;

        public FoodItemService(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnectionString");
        }

        public FoodItemVM GetFood(int id)
        {
            FoodItemVM foodItem = new FoodItemVM();
            SqlConnection connection = new SqlConnection(connectionString);
            string sql = $"select top 1 f.Id as FoodId, f.Name as FoodName, f.Description as foodDescription, " +
                $"f.Price as FoodPrice, f.Discount as FoodDiscount, f.ImageUrl, f.Active, r.Name as RestaurantName, r.Location, r.Id as RestaurantId " +
                $"from FoodItems f left join Restaurants r on f.RestaurantId = r.Id where f.Id = {id}";

            using (SqlCommand cmd = new SqlCommand(sql, connection))
            {
                connection.Open();
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        foodItem.Id = (int)rdr["FoodId"];
                        foodItem.Name = (string)rdr["FoodName"];
                        foodItem.Description = (string)rdr["foodDescription"];
                        foodItem.Price = (int)rdr["FoodPrice"];
                        foodItem.Discount = (int)rdr["FoodDiscount"];
                        foodItem.ImageUrl = (string)rdr["ImageUrl"];
                        foodItem.Active = (bool)rdr["Active"];
                        foodItem.Restaurant = new RestaurantVM()
                        {
                            Id = (int)rdr["RestaurantId"],
                            Name = (string)rdr["RestaurantName"],
                            Location = (string)rdr["Location"]
                        };
                    }
                    rdr.Close();
                }
            }
            connection.Close();

            return foodItem;
        }

        public List<FoodItemVM> Restaurant(int restaurantId, bool onlyActive)
        {
            List<FoodItemVM> foodItems = new List<FoodItemVM>();
            SqlConnection connection = new SqlConnection(connectionString);

            string sql = $"select * from FoodItems where RestaurantId = {restaurantId}";
            if (onlyActive)
            {
                sql = $"select * from FoodItems where RestaurantId = {restaurantId} and Active = 1";
            }
            using (SqlCommand cmd = new SqlCommand(sql, connection))
            {
                connection.Open();
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        FoodItemVM foodItem = new FoodItemVM();
                        foodItem.Id = (int)rdr["Id"];
                        foodItem.Name = (string)rdr["Name"];
                        foodItem.Description = (string)rdr["Description"];
                        foodItem.Price = (int)rdr["Price"];
                        foodItem.Discount = (int)rdr["Discount"];
                        foodItem.ImageUrl = (string)rdr["ImageUrl"];
                        foodItem.Active = (bool)rdr["Active"];
                        foodItems.Add(foodItem);
                    }
                    rdr.Close();
                }
            }
            connection.Close();

            return foodItems;
        }

        public void Create(FoodItemVM foodItem)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = $"insert into FoodItems(Name, Description, Price, Discount, ImageUrl, Active, RestaurantId) values ('{foodItem.Name}', '{foodItem.Description}', {foodItem.Price}, {foodItem.Discount}, '{foodItem.ImageUrl}', 1, {foodItem.RestaurantId})";

                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.CommandType = CommandType.Text;

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
        }

        public void Update(FoodItemVM foodItem)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = $"update FoodItems set Name = '{foodItem.Name}', Description = '{foodItem.Name}', Price = {foodItem.Price}, Discount = {foodItem.Discount}, ImageUrl = '{foodItem.ImageUrl}', Active = '{foodItem.Active}' where Id = {foodItem.Id}";

                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.CommandType = CommandType.Text;

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
        }

        public List<FoodItemVM> Search(string term)
        {
            List<FoodItemVM> foodItems = new List<FoodItemVM>();
            SqlConnection connection = new SqlConnection(connectionString);
            string sql = $"select f.Id as FoodId, f.Name as FoodName, f.Description as foodDescription, " +
                $"f.Price as FoodPrice, f.Discount as FoodDiscount, f.ImageUrl, f.Active, r.Name as RestaurantName, r.Location, r.Id as RestaurantId " +
                $"from FoodItems f left join Restaurants r on f.RestaurantId = r.Id where f.Active = 1 and (f.Description like '%{term}%' or f.Name like '%{term}%')";

            using (SqlCommand cmd = new SqlCommand(sql, connection))
            {
                connection.Open();
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        FoodItemVM foodItem = new FoodItemVM();
                        foodItem.Id = (int)rdr["FoodId"];
                        foodItem.Name = (string)rdr["FoodName"];
                        foodItem.Description = (string)rdr["foodDescription"];
                        foodItem.Price = (int)rdr["FoodPrice"];
                        foodItem.Discount = (int)rdr["FoodDiscount"];
                        foodItem.ImageUrl = (string)rdr["ImageUrl"];
                        foodItem.Active = (bool)rdr["Active"];
                        foodItem.Restaurant = new RestaurantVM()
                        {
                            Id = (int)rdr["RestaurantId"],
                            Name = (string)rdr["RestaurantName"],
                            Location = (string)rdr["Location"]
                        };

                        foodItems.Add(foodItem);
                    }
                    rdr.Close();
                }
            }
            connection.Close();

            return foodItems;
        }

    }
}
