﻿using FoodApp.Models.Tables;
using FoodApp.Models.ViewModels;
using Microsoft.Extensions.Configuration;
using Microsoft.SqlServer.Server;
using System.Data;
using System.Data.SqlClient;

namespace FoodApp.Data
{
    public class OrderService
    {
        string connectionString;
        string format = "yyyy-MM-dd HH:mm:ss";
        public OrderService(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnectionString");
        }

        public void Create(int foodItemId, int userId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = $"insert into Orders (FoodItemId, UserId, Cancelled, OrderedDateTime, DiscountApplied) values ({foodItemId}, {userId}, 0, '{DateTime.Now.ToString(format)}', 0)";

                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.CommandType = CommandType.Text;

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
        }

        public void Cancel(int foodItemId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = $"update Orders set Cancelled = 1, CancelledDateTime = '{DateTime.Now.ToString(format)}' where Id = {foodItemId}";

                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.CommandType = CommandType.Text;

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
        }

        public List<OrderVM> GetList(int userId)
        {
            List<OrderVM> orders = new List<OrderVM>();
            SqlConnection connection = new SqlConnection(connectionString);
            string sql = $"select o.Id as OrderId, o.OrderedDateTime, o.Cancelled, o.CancelledDateTime, f.Id as FoodId, f.* from Orders o " +
                $"inner join FoodItems f on o.FoodItemId = f.Id where o.UserId = {userId} Order By o.OrderedDateTime desc";
            using (SqlCommand cmd = new SqlCommand(sql, connection))
            {
                connection.Open();
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        OrderVM order = new OrderVM();
                        order.OrderId = (int)rdr["OrderId"];
                        order.Cancelled = (bool)rdr["Cancelled"];
                        order.OrderedDateTime = (DateTime)rdr["OrderedDateTime"];
                        order.CancelledDateTime = rdr["CancelledDateTime"].ToString();
                        order.FoodId = (int)rdr["FoodId"];
                        order.Name = (string)rdr["Name"];
                        order.Description = (string)rdr["Description"];
                        order.Price = (int)rdr["Price"];
                        order.Discount = (int)rdr["Discount"];
                        order.ImageUrl = (string)rdr["ImageUrl"];
                        orders.Add(order);
                    }
                    rdr.Close();
                }
            }
            connection.Close();

            return orders;
        }

        public OrderVM Get(int orderId, int userId)
        {
            OrderVM order = new OrderVM();
            SqlConnection connection = new SqlConnection(connectionString);
            string sql = $"select top 1 o.Id as OrderId, o.OrderedDateTime, o.Cancelled, o.CancelledDateTime, f.Id as FoodId, f.* from Orders o " +
                $"inner join FoodItems f on o.FoodItemId = f.Id where o.UserId = {userId} and o.Id = {orderId}";
            using (SqlCommand cmd = new SqlCommand(sql, connection))
            {
                connection.Open();
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        order.OrderId = (int)rdr["OrderId"];
                        order.Cancelled = (bool)rdr["Cancelled"];
                        order.OrderedDateTime = (DateTime)rdr["OrderedDateTime"];
                        order.CancelledDateTime = rdr["CancelledDateTime"].ToString();
                        order.FoodId = (int)rdr["FoodId"];
                        order.Name = (string)rdr["Name"];
                        order.Description = (string)rdr["Description"];
                        order.Price = (int)rdr["Price"];
                        order.Discount = (int)rdr["Discount"];
                        order.ImageUrl = (string)rdr["ImageUrl"];
                    }
                    rdr.Close();
                }
            }
            connection.Close();

            return order;
        }
    }
}
