﻿using FoodApp.Models.Tables;
using FoodApp.Models.ViewModels;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.Intrinsics.Arm;

namespace FoodApp.Data
{
    public class UserService
    {
        string connectionString;

        public UserService(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnectionString");
        }

        public bool Auth(LoginVM loginVM)
        {
            User user = new User();
            SqlConnection connection = new SqlConnection(connectionString);
            string sql = $"select top 1 * from users where Email = '{loginVM.Email}' and Password = '{loginVM.Password}'";
            using (SqlCommand cmd = new SqlCommand(sql, connection))
            {
                connection.Open();
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        user.Name = (string)rdr["Name"];
                        user.Email = (string)rdr["Email"];
                        user.Password = (string)rdr["Password"];
                        user.Id = (int)rdr["Id"];
                        user.Role = (string)rdr["Role"];
                    }
                    rdr.Close();
                }
            }
            connection.Close();
            if (user != null)
            {
                return true;
            }
            return false;
        }

        public User GetUser(string email)
        {
            User user = new User();
            SqlConnection connection = new SqlConnection(connectionString);
            string sql = $"select top 1 * from users where Email = '{email}'";
            using (SqlCommand cmd = new SqlCommand(sql, connection))
            {
                connection.Open();
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        user.Name = (string)rdr["Name"];
                        user.Email = (string)rdr["Email"];
                        user.Id = (int)rdr["Id"];
                        user.Role = (string)rdr["Role"];
                    }
                    rdr.Close();
                }
            }
            connection.Close();

            return user;
        }

        public void Create(RegisterVM registerVM)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = $"insert into users (Email, Name, Password, Role) values ('{registerVM.Email}', '{registerVM.Name}', '{registerVM.Password}', 'user')";

                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.CommandType = CommandType.Text;

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
        }
    }
}
