﻿using System.ComponentModel.DataAnnotations;

namespace FoodApp.Models.ViewModels
{
    public class RestaurantVM
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string Name { get; set; }

        [Required, MaxLength(500)]
        public string Location { get; set; }

    }
}
