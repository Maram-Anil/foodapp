﻿using System.ComponentModel.DataAnnotations;

namespace FoodApp.Models.Tables
{
    public class User
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string Name { get; set; }

        [Required, MaxLength(100), DataType(DataType.Password)]
        public string Password { get; set; }

        [Required, MaxLength(500), DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required, MaxLength(50)]
        public string Role { get; set; }
    }
}
