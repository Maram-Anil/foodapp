﻿using System.ComponentModel.DataAnnotations;

namespace FoodApp.Models.Tables
{
    public class FoodItem
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string Name { get; set; }

        [Required, MaxLength(500)]
        public string Description { get; set; }

        [Required]
        public int Price { get; set; }

        public int Discount { get; set; }

        public int RestaurantId { get; set; }

        public bool Active { get; set; }

        [Required, MaxLength(1000)]
        public string ImageUrl { get; set; }

    }
}
