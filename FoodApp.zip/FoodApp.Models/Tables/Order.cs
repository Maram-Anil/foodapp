﻿using System.ComponentModel.DataAnnotations;

namespace FoodApp.Models.Tables
{
    public class Order
    {
        public int Id { get; set; }

        [Required]
        public int FoodItemId { get; set; }

        [Required]
        public int UserId { get; set; }

        public bool Cancelled { get; set; }

        [Required]
        public DateTime OrderedDateTime { get; set; }

        public DateTime? CancelledDateTime { get; set; }

        public int DiscountApplied { get; set; }
    }
}
