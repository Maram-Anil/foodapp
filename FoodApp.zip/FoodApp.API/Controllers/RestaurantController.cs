﻿using FoodApp.Data;
using FoodApp.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace FoodApp.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class RestaurantController : ControllerBase
    {
        private readonly RestaurantService service;
        public IConfiguration Configuration { get; }
        public RestaurantController(IConfiguration configuration)
        {
            Configuration = configuration;
            service = new RestaurantService(configuration);
        }

        [HttpGet, Route("all")]
        public IActionResult GetAll()
        {
            int LoggedInUserID = Convert.ToInt32(User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value);
            var data = service.GetList(LoggedInUserID);
            return Ok(data);
        }

        [HttpPost]
        public IActionResult Post(RestaurantVM restaurantVM)
        {
            int LoggedInUserID = Convert.ToInt32(User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value);
            service.Create(restaurantVM, LoggedInUserID);
            return Ok();
        }

        public string LoggedInUserEmail => Convert.ToString(User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value);

    }
}
