﻿using FoodApp.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace FoodApp.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class OrdersController : ControllerBase
    {
        private readonly OrderService service;
        public IConfiguration Configuration { get; }
        public OrdersController(IConfiguration configuration)
        {
            Configuration = configuration;
            service = new OrderService(configuration);
        }

        [HttpGet, Route("order")]
        public IActionResult Order(int id)
        {
            int LoggedInUserID = Convert.ToInt32(User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value);
            service.Create(id, LoggedInUserID);
            return Ok();
        }

        [HttpGet, Route("cancel")]
        public IActionResult Cancel(int id)
        {
            service.Cancel(id);
            return Ok();
        }

        [HttpGet, Route("all")]
        public IActionResult All()
        {
            int LoggedInUserID = Convert.ToInt32(User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value);
            var list = service.GetList(LoggedInUserID);
            return Ok(list);
        }

        [HttpGet]
        public IActionResult Get(int id)
        {
            int LoggedInUserID = Convert.ToInt32(User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value);
            var data = service.Get(id, LoggedInUserID);
            return Ok(data);
        }
    }
}
