﻿CREATE TABLE [dbo].[Restaurants] (
    [Id]       INT            IDENTITY (1, 1) NOT NULL,
    [Name]     NVARCHAR (100) NOT NULL,
    [Location] NVARCHAR (100) NULL,
    [UserId]   INT            NOT NULL,
    CONSTRAINT [PK_Restaurans] PRIMARY KEY CLUSTERED ([Id] ASC)
);

