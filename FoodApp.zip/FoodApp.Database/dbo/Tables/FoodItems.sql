﻿CREATE TABLE [dbo].[FoodItems] (
    [Id]           INT             IDENTITY (1, 1) NOT NULL,
    [Name]         NVARCHAR (100)  NOT NULL,
    [Description]  NVARCHAR (500)  NULL,
    [Price]        INT             NOT NULL,
    [Discount]     INT             CONSTRAINT [DF_FoodItems_Discount] DEFAULT ((0)) NULL,
    [RestaurantId] INT             NOT NULL,
    [Active]       BIT             DEFAULT ((0)) NOT NULL,
    [ImageUrl]     NVARCHAR (1000) NULL,
    CONSTRAINT [PK_FoodItems] PRIMARY KEY CLUSTERED ([Id] ASC)
);

