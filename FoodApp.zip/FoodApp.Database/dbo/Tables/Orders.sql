﻿CREATE TABLE [dbo].[Orders] (
    [Id]                INT           IDENTITY (1, 11111) NOT NULL,
    [FoodItemId]        INT           NOT NULL,
    [UserId]            INT           NOT NULL,
    [Cancelled]         BIT           CONSTRAINT [DF_Orders_Cancelled] DEFAULT ((0)) NOT NULL,
    [OrderedDateTime]   DATETIME2 (7) NOT NULL,
    [CancelledDateTime] DATETIME2 (7) NULL,
    [DiscountApplied]   INT           CONSTRAINT [DF_Orders_DiscountApplied] DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED ([Id] ASC)
);

