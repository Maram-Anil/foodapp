﻿using FoodApp.Models.ViewModels;
using FoodApp.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Net.Http.Headers;

namespace FoodApp.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private HttpClient client;

        private string _baseurl;

        public HomeController(ILogger<HomeController> logger, IConfiguration configuration)
        {
            _logger = logger;
            client = new HttpClient();
            _baseurl = configuration.GetValue<string>("APIUrl");
            client.BaseAddress = new Uri(_baseurl);
        }

        public void SetSession()
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", BearerToken());
        }

        private string BearerToken()
        {
            return HttpContext.User.FindFirst("Token")?.Value;
        }

        public async Task<IActionResult> Index(string term)
        {
            ViewBag.Term = term?.Trim();
            SetSession();
            List<FoodItemVM> items = new List<FoodItemVM>();
            HttpResponseMessage responseMessage = await client.GetAsync("FoodItems/search?term=" + term);
            if (responseMessage.IsSuccessStatusCode)
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                items = JsonConvert.DeserializeObject<List<FoodItemVM>>(result);
            }

            return View(items);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> Order(int id)
        {
            SetSession();
            HttpResponseMessage responseMessage = await client.GetAsync("Orders/order?id=" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
            }

            return RedirectToAction("Index", "Orders");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}