﻿using FoodApp.Models.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Security.Claims;

namespace FoodApp.Web.Controllers
{
    public class UserController : Controller
    {
        private HttpClient client;

        private string _baseurl;

        public UserController(IConfiguration configuration)
        {
            client = new HttpClient();
            _baseurl = configuration.GetValue<string>("APIUrl");
            client.BaseAddress = new Uri(_baseurl);
        }

        public void SetSession()
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", BearerToken());
        }

        private string BearerToken()
        {
            return HttpContext.User.FindFirst("Token").Value;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginVM loginVM)
        {
            if (ModelState.IsValid == false)
            {
                return View(loginVM);
            }

            HttpResponseMessage responseMessage = await client.PostAsJsonAsync("User/Login", loginVM);
            if (responseMessage.IsSuccessStatusCode)
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                TokenVM token = JsonConvert.DeserializeObject<TokenVM>(result);
                var claims = new List<Claim>();
                claims.Add(new Claim(ClaimTypes.Email, token.Email));
                claims.Add(new Claim(ClaimTypes.Name, token.Name));
                claims.Add(new Claim("Token", token.Token));
                claims.Add(new Claim(ClaimTypes.Role, token.Role));
                var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var principal = new ClaimsPrincipal(identity);
                var props = new AuthenticationProperties();
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, props);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                TempData["errormessage"] = JsonConvert.DeserializeObject(result);
            }

            return View(loginVM);
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(RegisterVM registerVM)
        {
            if (ModelState.IsValid == false)
            {
                return View(registerVM);
            }
            HttpResponseMessage responseMessage = await client.PostAsJsonAsync("User/Register", registerVM);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Login");
            }
            else
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                TempData["errormessage"] = JsonConvert.DeserializeObject(result);
            }
            return View(registerVM);
        }

        [Authorize]
        public async Task<IActionResult> Orders()
        {
            return View();
        }

    }
}
