﻿using FoodApp.Models.ViewModels;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Security.Claims;
using System.Net.Http.Headers;

namespace FoodApp.Web.Controllers
{
    public class ManageRestaurantController : Controller
    {
        private HttpClient client;

        private string _baseurl;

        public ManageRestaurantController(IConfiguration configuration)
        {
            client = new HttpClient();
            _baseurl = configuration.GetValue<string>("APIUrl");
            client.BaseAddress = new Uri(_baseurl);
        }

        public void SetSession()
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", BearerToken());
        }

        private string BearerToken()
        {
            return HttpContext.User.FindFirst("Token").Value;
        }

        public async Task<IActionResult> Index()
        {
            SetSession();
            List<RestaurantVM> items = new List<RestaurantVM>();
            HttpResponseMessage responseMessage = await client.GetAsync("Restaurant/all");
            if (responseMessage.IsSuccessStatusCode)
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                items = JsonConvert.DeserializeObject<List<RestaurantVM>>(result);
            }

            return View(items);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Location")] RestaurantVM restaurantVM)
        {
            if (ModelState.IsValid == false)
            {
                return View(restaurantVM);
            }

            SetSession();
            HttpResponseMessage responseMessage = await client.PostAsJsonAsync("Restaurant", restaurantVM);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            else
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                TempData["errormessage"] = JsonConvert.DeserializeObject(result);
            }
            return RedirectToAction("Index");
        }

    }
}
