﻿using FoodApp.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace FoodApp.Web.Controllers
{
    [Authorize]
    public class OrdersController : Controller
    {
        private HttpClient client;

        private string _baseurl;

        public OrdersController(IConfiguration configuration)
        {
            client = new HttpClient();
            _baseurl = configuration.GetValue<string>("APIUrl");
            client.BaseAddress = new Uri(_baseurl);
        }

        public void SetSession()
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", BearerToken());
        }

        private string BearerToken()
        {
            return HttpContext.User.FindFirst("Token")?.Value;
        }

        public async Task<IActionResult> Index()
        {
            SetSession();
            List<OrderVM> items = new List<OrderVM>();
            HttpResponseMessage responseMessage = await client.GetAsync("Orders/all");
            if (responseMessage.IsSuccessStatusCode)
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                items = JsonConvert.DeserializeObject<List<OrderVM>>(result);
            }

            return View(items);
        }

        public async Task<IActionResult> Details(int id)
        {
            SetSession();
            OrderVM item = new OrderVM();
            HttpResponseMessage responseMessage = await client.GetAsync("Orders?id=" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                item = JsonConvert.DeserializeObject<OrderVM>(result);
            }

            return View(item);
        }

        public async Task<IActionResult> Cancel(int id)
        {
            SetSession();
            HttpResponseMessage responseMessage = await client.GetAsync("Orders/cancel?id=" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
            }

            return RedirectToAction("Index");
        }
    }
}
