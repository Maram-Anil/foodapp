﻿using FoodApp.Models.Tables;
using FoodApp.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace FoodApp.Web.Controllers
{
    [Authorize]
    public class ManageFoodItemController : Controller
    {
        private HttpClient client;

        private string _baseurl;

        public ManageFoodItemController(IConfiguration configuration)
        {
            client = new HttpClient();
            _baseurl = configuration.GetValue<string>("APIUrl");
            client.BaseAddress = new Uri(_baseurl);
        }

        public void SetSession()
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", BearerToken());
        }

        private string BearerToken()
        {
            return HttpContext.User.FindFirst("Token").Value;
        }

        public async Task<IActionResult> Index(int restaurantId)
        {
            ViewBag.RestaurantId = restaurantId;
            SetSession();
            List<FoodItemVM> items = new List<FoodItemVM>();
            HttpResponseMessage responseMessage = await client.GetAsync("FoodItems/all?restaurantId=" + restaurantId);
            if (responseMessage.IsSuccessStatusCode)
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                items = JsonConvert.DeserializeObject<List<FoodItemVM>>(result);
            }

            return View(items);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            SetSession();
            FoodItemVM item = new FoodItemVM();
            HttpResponseMessage responseMessage = await client.GetAsync("FoodItems?itemId=" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                item = JsonConvert.DeserializeObject<FoodItemVM>(result);
            }

            return View(item);
        }

        public async Task<IActionResult> Create(int restaurantId)
        {
            SetSession();
            List<RestaurantVM> items = new List<RestaurantVM>();
            HttpResponseMessage responseMessage = await client.GetAsync("Restaurant/all");
            if (responseMessage.IsSuccessStatusCode)
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                items = JsonConvert.DeserializeObject<List<RestaurantVM>>(result);
            }
            ViewBag.Restaurents = new SelectList(items, "Id", "Name", restaurantId);
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Description,Price,Discount,RestaurantId,Active,ImageUrl")] FoodItemVM foodItemVM)
        {
            if (ModelState.IsValid == false)
            {
                return View(foodItemVM);
            }
            HttpResponseMessage responseMessage = await client.PostAsJsonAsync("FoodItems", foodItemVM);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index", new { restaurantId = foodItemVM.RestaurantId });
            }
            else
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                TempData["errormessage"] = JsonConvert.DeserializeObject(result);
            }
            return View(foodItemVM);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            SetSession();
            FoodItemVM item = new FoodItemVM();
            HttpResponseMessage responseMessage = await client.GetAsync("FoodItems?itemId=" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                item = JsonConvert.DeserializeObject<FoodItemVM>(result);
            }

            List<RestaurantVM> items = new List<RestaurantVM>();
            HttpResponseMessage responseMessage1 = await client.GetAsync("Restaurant/all");
            if (responseMessage1.IsSuccessStatusCode)
            {
                var result = responseMessage1.Content.ReadAsStringAsync().Result;
                items = JsonConvert.DeserializeObject<List<RestaurantVM>>(result);
            }
            ViewBag.Restaurents = new SelectList(items, "Id", "Name");
            return View(item);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Description,Price,Discount,RestaurantId,Active,ImageUrl")] FoodItemVM foodItemVM)
        {
            if (id != foodItemVM.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid == false)
            {
                return View(foodItemVM);
            }
            HttpResponseMessage responseMessage = await client.PostAsJsonAsync("FoodItems/update", foodItemVM);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index", new { restaurantId = foodItemVM.RestaurantId });
            }
            else
            {
                var result = responseMessage.Content.ReadAsStringAsync().Result;
                TempData["errormessage"] = JsonConvert.DeserializeObject(result);
            }

            return View();
        }
    }
}
